# Manufacture

Manufacture is a simple command-line tool to create files with the specified name and type.

## Installation

You can install Manufacture using pip:

```sh
pip install manufacture
